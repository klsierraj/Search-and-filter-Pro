(function ( $ ) {

	"use strict";
	
	$(function () {
		
		// re init layout after ajax request
		$(document).on("sf:ajaxfinish", ".searchandfilter", function(e, data){
			//elementorFrontend.init();
			//elementorFrontend.elementsHandler.runReadyTrigger('.elementor-widget-posts');
			if(elementorFrontend){
				if(elementorFrontend.elementsHandler){
					if(elementorFrontend.elementsHandler.runReadyTrigger){
						elementorFrontend.elementsHandler.runReadyTrigger(data.targetSelector);
					}
				}
			}
		});

	});

	// load search forms in popups
	$( window ).on( 'elementor/frontend/init', function() {
		elementorFrontend.elements.$document.on( 'elementor/popup/show', ( e, id, document ) => {
			$('.elementor-popup-modal .searchandfilter').searchAndFilter();
		});
	});

}(jQuery));